# YLL POS V4.2 Vercel + Apps Script API

## 1) Apps Script
1. Create/replace `Code.gs` with `Code_API.gs` from this folder.
2. Deploy > Manage deployments > Edit > New version > Web app.
3. Execute as: Me. Who has access: Anyone.
4. Copy the `/exec` URL.

## 2) Vercel
1. Upload this whole folder to Vercel.
2. In Vercel Project > Settings > Environment Variables, add:
   `GAS_API_URL = your Apps Script /exec URL`
3. Redeploy.

## 3) Android Bluetooth print
1. Install RawBT on Android.
2. Pair printer POS58B in Android Bluetooth settings.
3. Open RawBT and select POS58B / 58mm.
4. In POS, checkout will copy receipt and try to open RawBT automatically on Android.

If RawBT does not open automatically, use More > 打印最后一单, or print from clipboard/share.
