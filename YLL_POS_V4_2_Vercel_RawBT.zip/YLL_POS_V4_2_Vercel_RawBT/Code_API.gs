/***********************
 * YLL POS V4.1 - Code.gs
 * Google Sheet + Apps Script + PWA
 ***********************/

const TZ = "Asia/Kuala_Lumpur";
const SHEETS = {
  PRODUCTS: "Products",
  ORDERS_MAIN: "Orders_Main",
  ORDERS_ITEMS: "Orders_Items",
  CUSTOMERS: "Customers",
  DEBTS: "Debts",
  PAYMENTS: "Payments",
  SETTINGS: "Settings"
};

/* ========= Web App / PWA ========= */
function doGet(e) {
  const page = (e && e.parameter && e.parameter.page) || "";

  if (page === "manifest") {
    return ContentService.createTextOutput(getManifest_())
      .setMimeType(ContentService.MimeType.JSON);
  }

  if (page === "sw") {
    return ContentService.createTextOutput(getServiceWorker_())
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }

  return HtmlService.createHtmlOutputFromFile("index")
    .setTitle("YLL FEEDS POS V4")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getManifest_() {
  return JSON.stringify({
    name: "YLL FEEDS POS",
    short_name: "YLL POS",
    description: "YLL FEEDS ENTERPRISE POS V4",
    start_url: "?pwa=1",
    scope: "./",
    display: "standalone",
    orientation: "any",
    background_color: "#050816",
    theme_color: "#050816",
    icons: [
      { src: "https://via.placeholder.com/192/0f172a/ffffff.png?text=YLL", sizes: "192x192", type: "image/png", purpose: "any maskable" },
      { src: "https://via.placeholder.com/512/0f172a/ffffff.png?text=YLL", sizes: "512x512", type: "image/png", purpose: "any maskable" }
    ]
  });
}

function getServiceWorker_() {
  return `
const CACHE_NAME = "yll-pos-v4-shell";
self.addEventListener("install", e => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", e => {
  // Apps Script POS：不强缓存接口，避免商品/库存/报表变旧。
});
`;
}

/* ========= 一键建立/修复表 ========= */
function setupPOS() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  ensureSheet_(ss, SHEETS.PRODUCTS, ["Code","Name","Price","Category","Image","Stock","Cost","Active"]);
  ensureSheet_(ss, SHEETS.ORDERS_MAIN, ["OrderId","Date","Subtotal","Discount","Total","Payment","ItemCount","Profit","Status"]);
  ensureSheet_(ss, SHEETS.ORDERS_ITEMS, ["OrderId","Date","Code","Name","Category","Qty","Price","Cost","Subtotal","Profit"]);
  ensureSheet_(ss, SHEETS.CUSTOMERS, ["CustomerId","Name","Phone","Note","Active"]);
  ensureSheet_(ss, SHEETS.DEBTS, ["DebtId","Date","CustomerId","CustomerName","OrderId","Amount","Paid","Balance","Status"]);
  ensureSheet_(ss, SHEETS.PAYMENTS, ["PaymentId","Date","CustomerId","CustomerName","DebtId","Amount","Method","Note"]);
  ensureSheet_(ss, SHEETS.SETTINGS, ["Key","Value"]);

  return "✅ POS V4 表格已经建立/修复完成";
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);

  if (sh.getLastRow() === 0) {
    sh.appendRow(headers);
  } else {
    const current = sh.getRange(1, 1, 1, Math.max(headers.length, sh.getLastColumn())).getValues()[0];
    const empty = current.every(v => String(v || "").trim() === "");
    if (empty) sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }

  sh.setFrozenRows(1);
}

/* ========= 商品 ========= */
function getProducts() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEETS.PRODUCTS);
  if (!sh || sh.getLastRow() <= 1) return [];

  const data = sh.getDataRange().getValues();
  const h = headerMap_(data[0]);

  return data.slice(1).map(row => productFromRow_(row, h)).filter(p => p.name && p.price > 0 && p.active !== false);
}

function productFromRow_(row, h) {
  const code = getCell_(row, h, ["code", "sku", "编号"]);
  const name = getCell_(row, h, ["name", "product", "商品", "名称"]);
  const price = Number(getCell_(row, h, ["price", "售价", "价格"])) || 0;
  const category = String(getCell_(row, h, ["category", "cat", "分类"]) || "未分类");
  const image = String(getCell_(row, h, ["image", "img", "图片"]) || "");
  const stock = Number(getCell_(row, h, ["stock", "库存"])) || 0;

  const costIdx = colIndex_(h, ["cost", "成本"]);
  let cost = Number(getCell_(row, h, ["cost", "成本"])) || 0;

  // 兼容旧表：只有在没有 Cost/成本 表头，而且 H 列真的是数字时，才当成成本。
  // 避免把 Active=TRUE 错读成 cost=1。
  if (!cost && costIdx < 0 && row.length >= 8 && typeof row[7] === "number") {
    cost = Number(row[7]) || 0;
  }

  const activeRaw = getCell_(row, h, ["active", "启用"]);
  const active = String(activeRaw || "TRUE").toUpperCase() !== "FALSE";

  return { code: String(code || ""), name: String(name || ""), price, category, image, stock, cost, active };
}

function getLowStock(limit) {
  limit = Number(limit || 5);
  return getProducts().filter(p => Number(p.stock || 0) <= limit).sort((a,b)=>a.stock-b.stock);
}

/* ========= 保存订单 ========= */
function saveOrder(cart, payment, discount) {
  const lock = LockService.getScriptLock();
  lock.waitLock(5000);

  try {
    if (!cart || !cart.length) throw new Error("购物车为空");

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    setupPOS();

    const productSh = ss.getSheetByName(SHEETS.PRODUCTS);
    const mainSh = ss.getSheetByName(SHEETS.ORDERS_MAIN);
    const itemSh = ss.getSheetByName(SHEETS.ORDERS_ITEMS);

    const productData = productSh.getDataRange().getValues();
    const h = headerMap_(productData[0]);
    const stockIdx = colIndex_(h, ["stock", "库存"]);
    if (stockIdx < 0) throw new Error("Products 表缺少 Stock/库存 列");

    const map = {};
    for (let r = 1; r < productData.length; r++) {
      const p = productFromRow_(productData[r], h);
      if (p.name) map[p.name] = { ...p, row: r + 1, rowData: productData[r] };
    }

    payment = normalizePayment_(payment);
    discount = Number(discount || 0);
    const orderId = generateOrderId_();
    const now = new Date();

    let subtotal = 0;
    let totalQty = 0;
    let profit = 0;
    const itemRows = [];

    cart.forEach(i => {
      const p = map[i.name];
      if (!p) throw new Error("商品不存在：" + i.name);

      const qty = Number(i.qty) || 0;
      const price = Number(i.price) || 0;
      if (qty <= 0) throw new Error("数量错误：" + i.name);
      if (Number(p.stock || 0) < qty) throw new Error("库存不足：" + i.name + " 剩 " + p.stock);

      const itemSubtotal = Number((qty * price).toFixed(2));
      const itemProfit = Number(((price - Number(p.cost || 0)) * qty).toFixed(2));

      subtotal += itemSubtotal;
      totalQty += qty;
      profit += itemProfit;

      itemRows.push([orderId, now, p.code, p.name, p.category, qty, price, p.cost, itemSubtotal, itemProfit]);
      p.stock = Number(p.stock || 0) - qty;
    });

    if (discount > subtotal) discount = subtotal;
    if (discount < 0) discount = 0;
    const total = Number((subtotal - discount).toFixed(2));

    mainSh.appendRow([orderId, now, Number(subtotal.toFixed(2)), Number(discount.toFixed(2)), total, payment, totalQty, Number(profit.toFixed(2)), "PAID"]);

    if (itemRows.length) {
      itemSh.getRange(itemSh.getLastRow() + 1, 1, itemRows.length, itemRows[0].length).setValues(itemRows);
    }

    // 批量更新库存
    const stockRange = productSh.getRange(2, stockIdx + 1, productData.length - 1, 1);
    const stockValues = stockRange.getValues();
    Object.values(map).forEach(p => {
      const index = p.row - 2;
      if (index >= 0 && index < stockValues.length) stockValues[index][0] = p.stock;
    });
    stockRange.setValues(stockValues);

    return { success: true, orderId, subtotal: Number(subtotal.toFixed(2)), discount: Number(discount.toFixed(2)), total };

  } finally {
    lock.releaseLock();
  }
}

/* ========= 报表 ========= */
function getTodayReport() {
  const today = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd");
  return getReportCore_(today, today).main;
}

function getFullReport(start, end) {
  const r = getReportCore_(start, end);
  return { ...r.main, categories: r.categories, topProducts: r.topProducts };
}

function getReportCore_(start, end) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const mainSh = ss.getSheetByName(SHEETS.ORDERS_MAIN);
  const itemSh = ss.getSheetByName(SHEETS.ORDERS_ITEMS);

  const s = new Date(start); s.setHours(0,0,0,0);
  const e = new Date(end); e.setHours(23,59,59,999);

  const main = { count:0, orders:0, total:0, profit:0, Cash:0, Transfer:0, MBB_QR:0, Debt:0 };
  const orderSet = new Set();

  if (mainSh && mainSh.getLastRow() > 1) {
    const data = mainSh.getDataRange().getValues();
    for (let i=1;i<data.length;i++) {
      const d = new Date(data[i][1]);
      if (d >= s && d <= e) {
        const orderId = data[i][0];
        const total = Number(data[i][4]) || 0;
        const pay = normalizePayment_(data[i][5]);
        main.total += total;
        main.profit += Number(data[i][7]) || 0;
        if (pay === "Cash") main.Cash += total;
        else if (pay === "Transfer") main.Transfer += total;
        else if (pay === "MBB_QR") main.MBB_QR += total;
        else if (pay === "Debt") main.Debt += total;
        orderSet.add(orderId);
      }
    }
  }

  main.count = orderSet.size;
  main.orders = orderSet.size;

  const categories = {};
  const topMap = {};

  if (itemSh && itemSh.getLastRow() > 1) {
    const items = itemSh.getDataRange().getValues();
    for (let i=1;i<items.length;i++) {
      const d = new Date(items[i][1]);
      if (d >= s && d <= e) {
        const name = String(items[i][3] || "");
        const cat = String(items[i][4] || "未分类");
        const qty = Number(items[i][5]) || 0;
        const subtotal = Number(items[i][8]) || 0;
        const profit = Number(items[i][9]) || 0;

        if (!categories[cat]) categories[cat] = { qty:0, total:0, profit:0 };
        categories[cat].qty += qty;
        categories[cat].total += subtotal;
        categories[cat].profit += profit;

        if (!topMap[name]) topMap[name] = { name, qty:0, total:0 };
        topMap[name].qty += qty;
        topMap[name].total += subtotal;
      }
    }
  }

  roundNumbers_(main);
  Object.values(categories).forEach(roundNumbers_);

  const topProducts = Object.values(topMap)
    .map(x => ({ name:x.name, qty:x.qty, total:Number(x.total.toFixed(2)) }))
    .sort((a,b)=>b.total-a.total)
    .slice(0,10);

  return { main, categories, topProducts };
}

function closeDayReport() {
  const r = getTodayReport();
  return { count:r.orders, total:r.total, profit:r.profit, Cash:r.Cash, Transfer:r.Transfer, MBB_QR:r.MBB_QR, Debt:r.Debt };
}

/* ========= 工具 ========= */
function normalizePayment_(payment) {
  let p = String(payment || "").toLowerCase().replace(/\s+/g,"_").trim();
  if (p === "cash") return "Cash";
  if (p === "transfer") return "Transfer";
  if (p === "mbb_qr" || p === "qr") return "MBB_QR";
  if (p === "debt" || p === "hutang" || p === "欠账") return "Debt";
  return "Cash";
}

function generateOrderId_() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEETS.ORDERS_MAIN);
  const dateStr = Utilities.formatDate(new Date(), TZ, "yyyyMMdd");
  if (!sh || sh.getLastRow() <= 1) return "ORD-" + dateStr + "-0001";

  const data = sh.getRange(2,1,sh.getLastRow()-1,1).getValues().flat();
  let max = 0;
  data.forEach(id => {
    id = String(id || "");
    if (id.startsWith("ORD-" + dateStr)) {
      const n = Number(id.split("-")[2]) || 0;
      if (n > max) max = n;
    }
  });
  return "ORD-" + dateStr + "-" + String(max + 1).padStart(4,"0");
}

function headerMap_(headers) {
  const map = {};
  headers.forEach((h,i) => {
    const key = String(h || "").toLowerCase().replace(/\s+/g,"").trim();
    if (key) map[key] = i;
  });
  return map;
}

function colIndex_(h, names) {
  for (const name of names) {
    const k = String(name).toLowerCase().replace(/\s+/g,"").trim();
    if (h[k] !== undefined) return h[k];
  }
  return -1;
}

function getCell_(row, h, names) {
  const idx = colIndex_(h, names);
  return idx >= 0 ? row[idx] : "";
}

function roundNumbers_(obj) {
  Object.keys(obj).forEach(k => {
    if (typeof obj[k] === "number") obj[k] = Number(obj[k].toFixed(2));
  });
}

function debugProducts(){
  const data = getProducts();
  Logger.log(JSON.stringify(data, null, 2));
  return data;
}


/* ========= Vercel API bridge ========= */
function doPost(e){
  try{
    const body = JSON.parse(e.postData && e.postData.contents ? e.postData.contents : "{}");
    const action = body.action;
    const args = body.args || [];
    let data;
    if(action === "getProducts") data = getProducts();
    else if(action === "saveOrder") data = saveOrder(args[0], args[1], args[2]);
    else if(action === "getTodayReport") data = getTodayReport();
    else if(action === "getFullReport") data = getFullReport(args[0], args[1]);
    else if(action === "closeDayReport") data = closeDayReport();
    else if(action === "getLowStock") data = getLowStock(args[0]);
    else throw new Error("Unknown action: " + action);
    return jsonOutput_({success:true, data:data});
  }catch(err){
    return jsonOutput_({success:false, error: err.message || String(err)});
  }
}

function jsonOutput_(obj){
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
